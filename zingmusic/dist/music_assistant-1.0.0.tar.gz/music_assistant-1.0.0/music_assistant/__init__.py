"""Music Assistant: The music library manager in python."""

from .mass import MusicAssistant  # noqa: F401
